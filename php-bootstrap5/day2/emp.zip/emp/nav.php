<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"><i class="bi bi-android"></i> </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                        <i class="bi bi-house-door"></i> หน้าแรก
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="departments.php">
                        <i class="bi bi-diagram-3"></i> ข้อมูลฝ่าย
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="employees.php">
                        <i class="bi bi-people"></i> ข้อมูลพนักงาน
                    </a>
                </li>

            </ul>
        </div>
    </div>
</nav>